package com.todoapp.model;

public enum Status {

	GettingStarted, AlmostThere, DoubleDone 
	
}